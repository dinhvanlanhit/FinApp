<div class="appBottomMenu">
    <a href="{{route('menu')}}"  class="item">
        <div class="col">
            <i  name="menu-outline" class="fas fa-list-ul"></i>
            <strong>Menu</strong>
        </div>
    </a>
    <a href="{{route('news')}}" class="item ">
        <div class="col">
            <i class="fas fa-newspaper"></i>
            <strong>Tin tức</strong>
        </div>
    </a>
    <a href="{{route('dashboard')}}/" class="item ">
        <div class="col">
            <i class="fas fa-home"></i>
            <strong>Trang chủ</strong>
        </div>
    </a>
    <a href="{{route('setting')}}" class="item">
        <div class="col">
            <i class="fas fa-cog"></i>
            <strong>Cài đặt</strong>
        </div>
    </a>
    <a href="#" data-toggle="modal" data-target="#modal-logout" class="item">
        <div class="col">
            <i class="fas fa-sign-out-alt"></i>
            <strong>Đăng xuất</strong>
        </div>
    </a>
</div>