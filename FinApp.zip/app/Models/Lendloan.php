<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Lendloan extends Model
{
    protected $table = 'lendloan';
}