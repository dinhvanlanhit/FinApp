<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Other_salaries extends Model
{
    protected $table = 'other_salaries';
}