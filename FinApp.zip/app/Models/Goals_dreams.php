<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Goals_dreams extends Model
{
    protected $table = 'goals_dreams';
}