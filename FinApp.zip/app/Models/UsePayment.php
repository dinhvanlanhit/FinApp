<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UsePayment extends Model
{
    protected $table = 'use_payment';
}