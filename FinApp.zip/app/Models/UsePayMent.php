<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UsePayMent extends Model
{
    protected $table = 'use_payment';
}