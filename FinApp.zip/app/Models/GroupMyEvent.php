<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GroupMyEvent extends Model
{
    protected $table = 'group_my_event';
}