<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MyEvent extends Model
{
    protected $table = 'my_event';
}