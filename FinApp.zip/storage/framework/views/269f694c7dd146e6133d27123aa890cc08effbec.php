<?php $__env->startSection('desktops'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminDesktops.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/pages/dashboard/dashboard.blade.php ENDPATH**/ ?>