    
<select class="form-control select2bs4" id="idWallet" name="idWallet">
    <option value="">-- Chọn Ví -- </option>   
    <?php $__currentLoopData = getWallet(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/fromControl/selectWallet.blade.php ENDPATH**/ ?>