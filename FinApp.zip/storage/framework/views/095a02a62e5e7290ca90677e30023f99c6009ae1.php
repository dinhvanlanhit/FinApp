<?php if(count($breadcrumbs)): ?>
    <ul class="breadcrumb">
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($breadcrumb->url && !$loop->last): ?>
                <li class="breadcrumb-item"><a href="<?php echo e($breadcrumb->url); ?>"><strong><?php echo e($breadcrumb->title); ?></strong></a></li>
            <?php else: ?>
                <li class="breadcrumb-item active"><strong><?php echo e($breadcrumb->title); ?></strong></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/includes/breadcrumbs.blade.php ENDPATH**/ ?>