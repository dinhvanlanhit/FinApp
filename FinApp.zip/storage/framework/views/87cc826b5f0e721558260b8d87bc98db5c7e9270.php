<div class="appBottomMenu">
    <a href="<?php echo e(route('menu')); ?>"  class="item">
        <div class="col">
            <i  name="menu-outline" class="fas fa-list-ul"></i>
            <strong>Menu</strong>
        </div>
    </a>
    <a href="<?php echo e(route('news')); ?>" class="item ">
        <div class="col">
            <i class="fas fa-newspaper"></i>
            <strong>Tin tức</strong>
        </div>
    </a>
    <a href="<?php echo e(route('dashboard')); ?>/" class="item ">
        <div class="col">
            <i class="fas fa-home"></i>
            <strong>Trang chủ</strong>
        </div>
    </a>
    <a href="<?php echo e(route('setting')); ?>" class="item">
        <div class="col">
            <i class="fas fa-cog"></i>
            <strong>Cài đặt</strong>
        </div>
    </a>
    <a href="#" data-toggle="modal" data-target="#modal-logout" class="item">
        <div class="col">
            <i class="fas fa-sign-out-alt"></i>
            <strong>Đăng xuất</strong>
        </div>
    </a>
</div><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminMobiles/includes/appBottomMenu.blade.php ENDPATH**/ ?>