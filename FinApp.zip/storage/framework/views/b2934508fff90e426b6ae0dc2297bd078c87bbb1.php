<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('admin_dashboard')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-tachometer-alt"></i>
          <p>
             Xem Tổng Quan
          </p>
        </a>
      </li>
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('admin_users')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-users"></i>
          <p>
             Người Dùng 
          </p>
        </a>
      </li>
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('admin_profile')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-user"></i>
          <p>
             Hô sơ cá nhân
          </p>
        </a>
      </li>
    </ul>
  </nav><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminApp/includes/menu.blade.php ENDPATH**/ ?>