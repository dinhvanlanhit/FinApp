
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/fontawesome-free/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/font-awesome/4.7.0/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/fontawesome-free/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/jquery-ui/jquery-ui.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/plugins/toastr/toastr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/dist/css/adminlte.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminDesktops/style.css')); ?>"><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminApp/partials/stylesheet.blade.php ENDPATH**/ ?>