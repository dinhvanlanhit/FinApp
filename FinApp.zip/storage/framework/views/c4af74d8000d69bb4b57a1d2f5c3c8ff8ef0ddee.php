<?php $__env->startSection('desktops'); ?>
<div class="card">
    <div class="card-header">
      <h3 class="card-title">
        <i class="ion ion-clipboard mr-1"></i>
        Danh Sách
      </h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body card-body-dashboard">
        <div class="row">
          <div class="col-md-12">
              <table class="table table-bordered row-border hover text-small" id="wallet-table"></table>
          </div>
        </div>
        
        
    </div>
    <!-- /.card-body -->
    <div class="card-footer clearfix">
      <a  href="<?php echo e(route('dashboard')); ?>/" class="btn btn-danger float-feft"><i class="fas fa-long-arrow-alt-left"></i> Quay lại</a>
    </div>
  </div>
<?php echo $__env->make('AdminDesktops.pages.wallet.include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<script src="<?php echo e(asset('app/desktops/wallet/wallet.js')); ?>"></script>
<script> 
    var wallet = new wallet(); 
    wallet.datas={
        routes:{
          datatable:"<?php echo e(route('wallet_table')); ?>",
          insert:"<?php echo e(route('wallet_insert')); ?>",
          update:"<?php echo e(route('wallet_update')); ?>",
          delete:"<?php echo e(route('wallet_delete')); ?>",
        }
    }   
    wallet.runJS();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminDesktops.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/pages/wallet/index.blade.php ENDPATH**/ ?>