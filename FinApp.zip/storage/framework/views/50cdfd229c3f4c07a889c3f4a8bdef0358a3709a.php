<?php $__env->startSection('desktops'); ?>

        <form id="formProfile">
            <div class="row">
                <div class="col-md-3">
                  <div class="card card-primary card-outline">
                    <div class="card-body box-profile">
                  
                      <div class="text-center">
                        <label for="changeAvatar">
                        <img class="img-responsive btn-block"   id="user_avatar_profile" 
                         <?php if(empty(Auth::user()->avatar)): ?>
                                src="<?php echo e(asset('./data/default/profile-default.png')); ?>"    
                         <?php else: ?>
                            <?php if(file_exists('./data/users/users'.Auth::user()->id.'/'.Auth::user()->avatar)): ?>
                                src="<?php echo e(asset('./data/users/users'.Auth::user()->id.'/'.Auth::user()->avatar)); ?>"
                            <?php else: ?>
                                    src="<?php echo e(asset('./data/default/profile-default.png')); ?>" 
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        alt="User profile picture">
                            </label>
                    </div>
                   
                    <h3 class="profile-username text-center full_name_show"><?php echo e(Auth::user()->full_name); ?></h3>
                      <p class="text-muted text-center full_email_show"><?php echo e(Auth::user()->email); ?></p>
                    <input type="file"  id="changeAvatar" class="d-none" name="avatar"/>
                    </div>
                    <!-- /.card-body -->
                  </div>
                </div>
                <!-- /.col -->
                <div class="col-md-9">
                  <div class="card">
                    <div class="card-header p-2">
                      <ul class="nav nav-pills">
                        <li class="nav-item"><a class="nav-link active" href="#userInfo" data-toggle="tab">Thông tin cá nhân</a></li>
                        <li class="nav-item"><a class="nav-link  " href="#userChanePass" data-toggle="tab">Thay đổi mật khẩu</a></li>
                      </ul>
                    </div><!-- /.card-header -->
                    <div class="card-body">
                      <div class="tab-content">
                        <div class="tab-pane active" id="userInfo">
                          <form class="form-horizontal">
                            <div class="form-group ">
                              <label for="full_name" class="col-form-label">Họ Và Tên</label>
                                <input type="text" class="form-control" value="<?php echo e($users->full_name); ?>" id="full_name" name="full_name" placeholder="Họ và tên ....">
                             
                            </div>
                            <div class="form-group">
                              <label for="email" class="col-form-label">Email</label>
                                <input type="email" class="form-control" id="email" value="<?php echo e($users->email); ?>" name="email" placeholder="Email">
                              
                            </div>
                            <div class="form-group">
                                <label for="birthday" class="col-form-label">Ngày Sinh</label>
                                <input type="text" class="form-control" id="birthday" name="birthday" value="<?php echo e($users->birthday); ?>" placeholder="... ">
                                
                            </div>
                            <div class="form-group">
                              <label for="inputName2" class=" col-form-label">Giới Tính</label>
                              <div class="">
                                <div class="form-group clearfix">
                                    <div class="icheck-primary d-inline">
                                        <input type="radio" id="radioPrimary3" value="1" <?php echo e($users->sex==1?'checked':''); ?> name="sex">
                                        <label for="radioPrimary3">
                                           Nam
                                        </label>
                                        
                                      </div>
                                    <div class="icheck-primary d-inline">
                                      <input type="radio" id="radioPrimary2"  value="0" <?php echo e($users->sex==0?'checked':''); ?> name="sex">
                                      <label for="radioPrimary2">
                                          Nữ
                                      </label>
                                    </div>
                                    
                                  </div>
                              </div>
                            </div>
                            <div class="form-group ">
                              <label for="introduce" class=" col-form-label">Giới Thiệu Bản Thân</label>
                             
                                <textarea class="form-control" id="introduce" name="introduce" placeholder="..."><?php echo $users->introduce; ?></textarea>
                             
                            </div>
                            <div class="form-group ">
                              <label for="address" class=" col-form-label">Địa chỉ</label>
                             
                                <input type="text" class="form-control" id="address" name="address_1" value="<?php echo e($users->address_1); ?>" placeholder="Địa chỉ ... ">
                             
                            </div>
                            <div class="form-group ">
                                <label for="phone_number" class=" col-form-label">Số Điện Thoại</label>
                              
                                <input type="text" class="form-control" id="phone_number" name="phone_number" value="<?php echo e($users->phone_number); ?>" placeholder="Địa chỉ ... ">
                           
                            </div>
                            <div class="form-group ">
                                <label for="address" class=" col-form-label">Mối Quan Hệ</label>
                           
                                    <select name="user_type" class="form-control" >
                                            <option <?php echo e($users->user_type==0?'selected':''); ?>  value="0">Độc Thân</option>
                                            <option <?php echo e($users->user_type==1?'selected':''); ?>   value="1">Có Gia Đình</option>
                                    </select>
                               
                            </div>
                            <div class="form-group ">
                              <div class="">
                                  <a  href="<?php echo e(route('dashboard')); ?>/" class="btn btn-danger float-feft"><i class="fas fa-long-arrow-alt-left"></i> Quay lại</a>
                                <button type="submit" id="onSave" class="btn btn-danger">Lưu</button>
                              </div>
                            </div>
                          </form>
                        </div>
                        <div class="tab-pane" id="userChanePass">
                            <form class="form-horizontal">
                              <div class="form-group row">
                                <label for="old_password" class="col-sm-2 col-form-label"> Nhập lại mật khẩu củ 
                                    <span class="text-danger old_password"></span>
                                </label>
                                <div class="col-sm-10">
                                  <input type="password" class="form-control" id="old_password" name="old_password" placeholder="">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="password1" class="col-sm-2 col-form-label"> Nhập mật khẩu mới
                                    <span class="text-danger old_password"></span>
                                </label>
                                <div class="col-sm-10">
                                  <input type="password" class="form-control"  id="password1" name="password1" >
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="inputName2" class="col-sm-2 col-form-label">
                                    Xác nhận lại mật khẩu mới
                                    <span class="text-danger old_password"></span>
                                </label>
                                <div class="col-sm-10">
                                  <input type="password" class="form-control" id="password2" name="password2" placeholder="...">
                                </div>
                              </div>
                              <div class="form-group row">
                                <div class="offset-sm-2 col-sm-10">
                                  <a  href="<?php echo e(route('dashboard')); ?>/" class="btn btn-danger float-feft"><i class="fas fa-long-arrow-alt-left"></i> Quay lại</a>
                                  <button type="submit" class="btn btn-danger">Lưu</button>
                                </div>
                              </div>
                            </form>
                          </div>
                        <!-- /.tab-pane -->
                      </div>
                      <!-- /.tab-content -->
                    </div><!-- /.card-body -->
                        <!-- /.card-body -->
                       
                  </div>
                  <!-- /.nav-tabs-custom -->
                </div>
                <!-- /.col -->
              </div>
        </form>

        
        
 


<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<script src="<?php echo e(asset('app/desktops/profile/profile.js')); ?>"></script>
<script> 
    var profile = new profile(); 
    profile.datas={
        birthday:"<?php echo e($users->birthday); ?>",
        routes:{
          profile:"<?php echo e(route('profile')); ?>",
          uploadFile:"<?php echo e(route('uploadFile')); ?>",
        }
    }   
    profile.runJS();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminDesktops.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/pages/profile/profile.blade.php ENDPATH**/ ?>