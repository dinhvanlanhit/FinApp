<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('dashboard')); ?>/" class="nav-link ">
          <i class="nav-icon fas fa-tachometer-alt"></i>
          <p>
             Tổng Quan
          </p>
        </a>
      </li>
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('event')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-umbrella"></i>
          <p>
            Tiệc Tùng
           
          </p>
        </a>
      
      </li>
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('shopping')); ?>" class="nav-link ">
          <i class="nav-icon fa fa-shopping-bag"></i>
          <p>
            Mua Sắm
            
          </p>
        </a>
        
        
      </li>
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('cost')); ?>" class="nav-link  ">
          <i class="nav-icon fas fa-copy"></i>
          <p>
            Chi Tiêu
           
          </p>
        </a>
      
      </li>
      <li class="nav-item menu-open ">
        <a href="<?php echo e(route('salary')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-credit-card"></i>
          <p>
            Thu Nhập
           
          </p>
        </a>
        
      </li>
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('debt')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-university"></i>
          <p>
            Khoản Nợ
           
          </p>
        </a>
      </li>
      <li class="nav-item menu-open ">
        <a href="<?php echo e(route('lendloan')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-area-chart"></i>
          <p>
            Cho Vay
            
          </p>
        </a>
      </li>
      
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('invest')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-building"></i>
          <p>
            Đầu Tư
          
          </p>
        </a>
        
      </li>
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('goals_dreams')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-futbol-o"></i>
          <p>
            Mục Tiêu 
          
          </p>
        </a>
        
      </li>
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('wallet')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-money"></i>
          <p>
            Ví Tiền
          
          </p>
        </a>
        
      </li>
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('asset')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-hdd-o"></i>
          <p>
            Tài Sản
          
          </p>
        </a>
        
      </li>
      <li class="nav-item menu-open">
        <a href="<?php echo e(route('profile')); ?>" class="nav-link ">
          <i class="nav-icon fas fa-user"></i>
          <p>
             Hô sơ cá nhân
          </p>
        </a>
      </li>
    </ul>
  </nav><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/includes/menu.blade.php ENDPATH**/ ?>