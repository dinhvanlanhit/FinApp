<aside class="main-sidebar elevation-4 sidebar-light-lightblue">

    <a href="<?php echo e(route('dashboard')); ?>" class="brand-link">
      <img width="100%" src="<?php echo e(asset('SytemFinApp/logo/logofinapp.jpg')); ?>"/>
    </a>
    <div class="sidebar">
      <?php echo $__env->make('AdminDesktops.includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </aside>
<?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/includes/sidebar.blade.php ENDPATH**/ ?>