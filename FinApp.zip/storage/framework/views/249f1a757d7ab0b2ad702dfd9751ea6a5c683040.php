<div class="form-group">
    <div class="input-group">
        <input type="text"  id="daterange" class="form-control text-center">
        <div class="input-group-prepend" >
            <span class="input-group-text">
              <i class="far fa-calendar-alt"></i>
            </span>
          </div>
      </div>
</div>
<input class="form-control input-sm text-center d-none" type="text" name="dateBegin" id="dateBegin">
<input class="form-control input-sm text-center d-none" type="text" name="dateEnd" id="dateEnd"><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/fromControl/dateRange.blade.php ENDPATH**/ ?>