
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/fontawesome-free/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/jquery-ui/jquery-ui.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/plugins/toastr/toastr.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/dist/css/adminlte.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('AdminWebsites/style.css')); ?>"><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\ManegerMotelRoom\resources\views/AdminDesktops/partials/stylesheet.blade.php ENDPATH**/ ?>