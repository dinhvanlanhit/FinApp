
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>MOTEL-ROOM</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php echo $__env->make('AdminDesktops.partials.stylesheet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed text-sm">
    <div class="wrapper">
        <!-- Navbar -->
        <?php echo $__env->make('AdminDesktops.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /.navbar -->
        <?php echo $__env->make('AdminDesktops.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content-wrapper">
          <br>
          <section class="content">
            <div class="container-fluid">
                <?php echo $__env->yieldContent('layout'); ?>
            </div><!-- /.container-fluid -->
          </section>
          <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php echo $__env->make('AdminDesktops.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('AdminDesktops.includes.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
        <?php echo $__env->make('AdminDesktops.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('javascript'); ?>
</body>
</html>
<?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\ManegerMotelRoom\resources\views/AdminDesktops/layouts/layout.blade.php ENDPATH**/ ?>