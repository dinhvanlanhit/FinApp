<nav class="main-header navbar navbar-expand navbar-dark navbar-danger">
    <!-- Left navbar links -->
    <ul class="navbar-nav ">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item  ">
        <a href="<?php echo e(route('wallet')); ?>" class="nav-link active"> <b> <i class="fa fa-money"></i> : </b><b class="surplus" id="surplus"> <?php echo e(number_format(surplus())); ?></b><b> VNĐ </b></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('profile')); ?>" class="nav-link active"><b> <i class="fa fa-user"></i> <?php echo e(Auth::user()->full_name); ?></b></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link"><b>Liên Hệ</b></a>
      </li>
    </ul>
    <!-- SEARCH FORM -->

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      
     
      <li class="nav-item">
        <a href="javascript:void(0)" data-toggle="modal" data-target="#modal-logout" class="nav-link" role="button">
          <i class="fas fa-sign-out-alt"></i>
        </a>
      </li>
    </ul>
  </nav><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/includes/header.blade.php ENDPATH**/ ?>