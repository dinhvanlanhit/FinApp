<div class="header header-fixed header-auto-show header-logo-app">
    <a href="index.html" class="header-title">AZURES</a>
    <a href="#" data-menu="menu-main" class="header-icon header-icon-1"><i class="fas fa-bars"></i></a>
    <a href="#" data-toggle-theme class="header-icon header-icon-2 show-on-theme-dark"><i class="fas fa-sun"></i></a>
    <a href="#" data-toggle-theme class="header-icon header-icon-2 show-on-theme-light"><i class="fas fa-moon"></i></a>
    <a href="#" data-menu="menu-highlights" class="header-icon header-icon-3"><i class="fas fa-brush"></i></a>
</div><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\AppTruck\resources\views/AppXeTai/includes/app-header.blade.php ENDPATH**/ ?>