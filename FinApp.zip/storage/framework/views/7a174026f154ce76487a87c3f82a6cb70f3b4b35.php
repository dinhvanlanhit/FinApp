<?php $__env->startSection('desktops'); ?>
<div class="card">
    <div class="card-header">
      <h3 class="card-title">
        <i class="ion ion-clipboard mr-1"></i>
        Danh Sách
      </h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body card-body-dashboard">
        <form id="formSearch">
            <div class="row">
              <div class="col-md-2">
                <div class="form-group">
                   
                    <select class="form-control select2bs4" id="idTypeShopping" style="width: 100%;" name="idTypeShopping">
                        <option value="">-- Tất cả -- </option>    
                        <?php $__currentLoopData = $typeshopping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->type_name); ?></option>                      
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
              </div>
                <div class="col-md-3">
                  <div class="form-group">
                        <input class="form-control" id="search" name="search" placeholder="Tìm kiếm ...."/>
                  </div>
                </div>
                <div class="col-md-3">
                        <?php echo $__env->make('AdminDesktops.fromControl.dateRange', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <button type="submit" class="btn btn-info btn-block formSearch">Tìm kiếm</button>
                      </div>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <button type="button"  class="btn btn-success btn-block" id="btn-insert">Thêm mới</button>
                   </div>
                </div>
            </div>
        </form>
        <div class="row">
          <div class="col-md-12">
              <table class="table table-bordered row-border hover" id="shopping-table"></table>
          </div>
        </div>
        
        
    </div>
    <!-- /.card-body -->
    <div class="card-footer clearfix">
      <a  href="<?php echo e(route('dashboard')); ?>/" class="btn btn-danger float-feft"><i class="fas fa-long-arrow-alt-left"></i> Quay lại</a>
    </div>
  </div>
<?php echo $__env->make('AdminDesktops.pages.shopping.include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('app/desktops/shopping/shopping.js')); ?>"></script>
<script> 
    var shopping = new shopping(); 
    shopping.datas={
        routes:{
          datatable:"<?php echo e(route('shopping_table')); ?>",
          insert:"<?php echo e(route('shopping_insert')); ?>",
          update:"<?php echo e(route('shopping_update')); ?>",
          delete:"<?php echo e(route('shopping_delete')); ?>",
        }
    }   
    shopping.runJS();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminDesktops.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/pages/shopping/index.blade.php ENDPATH**/ ?>