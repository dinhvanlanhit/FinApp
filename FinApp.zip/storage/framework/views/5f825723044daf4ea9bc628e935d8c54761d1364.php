<footer class="main-footer text-center">
    <strong>Copyright &copy; 2020 <a href="https:24hcode.net">Đinh Văn Lệ</a>.</strong>

    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.4
    </div>
  </footer><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminDesktops/includes/footer.blade.php ENDPATH**/ ?>