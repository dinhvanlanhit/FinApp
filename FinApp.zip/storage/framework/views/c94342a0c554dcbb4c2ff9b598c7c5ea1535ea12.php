<div id="menu-main" class="menu menu-box-right menu-box-detached rounded-m" data-menu-width="260" 

data-menu-active="nav-welcome" data-menu-effect="menu-over">
			
</div><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\AppTruck\resources\views/AppXeTai/includes/app-menu-main.blade.php ENDPATH**/ ?>