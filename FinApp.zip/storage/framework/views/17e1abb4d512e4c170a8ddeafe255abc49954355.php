<div class="form-group">
    <div class="input-group ">
        <input type="text"  
        <?php if(isset($daterange)): ?>
           id="<?php echo e($daterange); ?>"
        <?php else: ?>
           id="daterange"
        <?php endif; ?>
        class="form-control text-center daterange input-sm">
        <div class="input-group-prepend" >
            <span class="input-group-text">
              <i class="far fa-calendar-alt"></i>
            </span>
          </div>
      </div>
</div>
<input class="form-control input-sm text-center d-none" type="text"
<?php if(isset($dateBegin)): ?>
id="<?php echo e($dateBegin); ?>"
name="<?php echo e($dateBegin); ?>"
<?php else: ?>
id="dateBegin"
name="dateBegin"
<?php endif; ?>>

<input class="form-control input-sm text-center d-none" type="text"
<?php if(isset($dateEnd)): ?>
id="<?php echo e($dateEnd); ?>"
name="<?php echo e($dateEnd); ?>"
<?php else: ?>
id="dateEnd"
name="dateEnd"
<?php endif; ?>>
<?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\FinApp\resources\views/AdminApp/fromControl/dateRange.blade.php ENDPATH**/ ?>