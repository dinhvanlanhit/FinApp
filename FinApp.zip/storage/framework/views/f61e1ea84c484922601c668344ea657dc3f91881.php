<div class="appBottomMenu">
    <a href="#" data-toggle="modal" data-target="#sidebarPanel" class="item">
        <div class="col">
            <i  name="menu-outline" class="fas fa-list-ul"></i>
            <strong>Menu</strong>
        </div>
    </a>
    <a href="<?php echo e(route('mobile-news')); ?>" class="item ">
        <div class="col">
            <i class="fas fa-newspaper"></i>
            <strong>Tin tức</strong>
        </div>
    </a>

    <a href="<?php echo e(route('mobile-home')); ?>" class="item active">
        <div class="col">
            <i class="fas fa-home"></i>
            <strong>Trang chủ</strong>
        </div>
    </a>
    <a href="#" class="item">
        <div class="col">
            <i class="fas fa-search"></i>
            <strong>Tìm kiếm</strong>
        </div>
    </a>
    <a href="<?php echo e(route('mobile-setting')); ?>" class="item">
        <div class="col">
            <i class="fas fa-cog"></i>
            <strong>Cài đặt</strong>
        </div>
    </a>
</div><?php /**PATH D:\PhanMem\Xampp743\htdocs\SoucrePHP\ManegerMotelRoom\resources\views/AdminMobiles/includes/appBottomMenu.blade.php ENDPATH**/ ?>